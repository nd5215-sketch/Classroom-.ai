import os, json, base64, re, random
from flask import Flask, request, jsonify, send_from_directory
from openai import OpenAI

app = Flask(__name__, static_folder="static")
app.config["MAX_CONTENT_LENGTH"] = 16 * 1024 * 1024

MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))

def image_data(file):
    raw = file.read()
    if not raw:
        raise ValueError("사진 파일이 비어 있어요.")
    mime = file.mimetype or "image/jpeg"
    if mime not in ("image/jpeg", "image/png", "image/webp", "image/gif"):
        raise ValueError("JPG, PNG, WEBP 사진만 올려 주세요.")
    return f"data:{mime};base64," + base64.b64encode(raw).decode("ascii")

def ask_ai(rel_image, room_image):
    prompt = """
두 장의 이미지를 분석해 교실 자리 배치에 필요한 정보를 추출하세요.
첫 번째 이미지는 친구 관계표, 두 번째 이미지는 교실 자리 배치 모양입니다.
관계표에서 실제로 표시되거나 적힌 정보만 읽으세요. 사진만으로 학생의 성격이나 관계를 추측하지 마세요.
관계 종류는 talk(수다/떠듦), conflict(불편/싸움/분리 표시), friend(친함), neutral(보통/불명) 중 하나로 정규화하세요.
교실 그림에서는 책상/좌석으로 보이는 위치만 추출하세요. 책상이 직사각형으로 배열되지 않아도 각 좌석을 row,col 격자 좌표로 근사하세요.
칠판/교사 위치가 보이면 front_direction을 "top", "bottom", "left", "right" 중 하나로 표시하고, 불확실하면 "top"으로 하세요.
좌석이 안 보이거나 판독이 어렵다면 추측하지 말고 confidence를 낮추고 notes에 알려 주세요.
이름과 관계는 중복을 제거하세요. 관계표에 없는 관계는 만들지 마세요.
반드시 JSON 객체만 반환하세요.
"""
    schema = {
      "type":"object",
      "properties":{
        "students":{"type":"array","items":{"type":"string"}},
        "relationships":{"type":"array","items":{"type":"object","properties":{
          "student_a":{"type":"string"},"student_b":{"type":"string"},
          "type":{"type":"string","enum":["talk","conflict","friend","neutral"]},
          "evidence":{"type":"string"}
        },"required":["student_a","student_b","type","evidence"],"additionalProperties":False}},
        "seating":{"type":"object","properties":{
          "rows":{"type":"integer","minimum":1,"maximum":20},
          "cols":{"type":"integer","minimum":1,"maximum":20},
          "front_direction":{"type":"string","enum":["top","bottom","left","right"]},
          "seats":{"type":"array","items":{"type":"object","properties":{
            "row":{"type":"integer","minimum":0,"maximum":19},
            "col":{"type":"integer","minimum":0,"maximum":19}
          },"required":["row","col"],"additionalProperties":False}}
        },"required":["rows","cols","front_direction","seats"],"additionalProperties":False},
        "confidence":{"type":"string","enum":["high","medium","low"]},
        "notes":{"type":"array","items":{"type":"string"}}
      },
      "required":["students","relationships","seating","confidence","notes"],
      "additionalProperties":False
    }
    response = client.responses.create(
      model=MODEL,
      input=[{"role":"user","content":[
        {"type":"input_text","text":prompt},
        {"type":"input_image","image_url":rel_image,"detail":"high"},
        {"type":"input_image","image_url":room_image,"detail":"high"}
      ]}],
      text={"format":{"type":"json_schema","name":"classroom_photo_analysis","strict":True,"schema":schema}}
    )
    return json.loads(response.output_text)

def optimize(data):
    students = list(dict.fromkeys([s.strip() for s in data.get("students",[]) if s.strip()]))
    rels = data.get("relationships",[])
    seating = data.get("seating",{})
    seats = seating.get("seats",[])
    if not students:
        raise ValueError("관계표에서 친구 이름을 찾지 못했어요. 사진을 더 선명하게 찍어 주세요.")
    if not seats:
        raise ValueError("자리 모양 사진에서 책상을 찾지 못했어요. 책상 전체가 보이게 다시 찍어 주세요.")
    if len(students) > len(seats):
        raise ValueError(f"친구는 {len(students)}명인데 인식한 자리는 {len(seats)}개예요. 자리 모양 사진을 확인해 주세요.")
    index = {name:i for i,name in enumerate(students)}
    weights = {}
    for r in rels:
        a,b = r.get("student_a"),r.get("student_b")
        if a in index and b in index and a != b:
            w = {"conflict":30,"talk":18,"friend":-2,"neutral":0}.get(r.get("type"),0)
            weights[tuple(sorted((index[a],index[b])))] = max(weights.get(tuple(sorted((index[a],index[b]))),-999),w)
    # Use Manhattan-neighbor seats; preserve detected desk geometry as a grid.
    coords = [(int(s["row"]),int(s["col"])) for s in seats]
    adjacency = []
    for i,(r,c) in enumerate(coords):
        for j,(rr,cc) in enumerate(coords):
            if j > i and abs(r-rr)+abs(c-cc)==1:
                adjacency.append((i,j))
    if not adjacency and len(coords)>1:
        # Fallback for layouts with gaps: connect each seat to its nearest neighbor.
        for i,(r,c) in enumerate(coords):
            j = min((j for j in range(len(coords)) if j != i),
                    key=lambda j: (coords[j][0]-r)**2+(coords[j][1]-c)**2)
            pair=tuple(sorted((i,j)))
            if pair not in adjacency: adjacency.append(pair)
    best=None; best_score=float("inf")
    # Randomized greedy assignment with local swaps.
    for _ in range(450):
        order=sorted(range(len(students)),key=lambda a:sum(1 for (x,y),w in weights.items() if a in (x,y) and w>0),reverse=True)
        random.shuffle(order)
        order.sort(key=lambda a:sum(1 for (x,y),w in weights.items() if a in (x,y) and w>0),reverse=True)
        assigned=[None]*len(coords)
        available=set(range(len(coords)))
        for person in order:
            def cost(pos):
                total=0
                for other_pos,other in enumerate(assigned):
                    if other is not None and tuple(sorted((person,other))) in weights:
                        edge=tuple(sorted((pos,other_pos)))
                        if edge in adjacency:
                            total += weights[tuple(sorted((person,other)))]
                return total+random.random()*0.2
            pos=min(available,key=cost)
            assigned[pos]=person; available.remove(pos)
        score=sum(weights.get(tuple(sorted((assigned[i],assigned[j]))),0)
                  for i,j in adjacency if assigned[i] is not None and assigned[j] is not None)
        if score<best_score:
            best_score=score;best=assigned[:]
    result=[]
    for pos,person in enumerate(best):
        r,c=coords[pos]
        result.append({"row":r,"col":c,"student":students[person] if person is not None else ""})
    return {"students":students,"relationships":rels,"seating":seating,"assignments":result,
            "confidence":data.get("confidence","low"),"notes":data.get("notes",[]),
            "adjacent_relationships":sum(1 for i,j in adjacency if best[i] is not None and best[j] is not None and tuple(sorted((best[i],best[j]))) in weights and weights[tuple(sorted((best[i],best[j])))]>0)}

@app.get("/")
def home():
    return send_from_directory("static","index.html")

@app.post("/api/analyze")
def analyze():
    if not os.environ.get("OPENAI_API_KEY"):
        return jsonify(error="서버에 OPENAI_API_KEY가 설정되지 않았어요."), 503
    rel=request.files.get("relationship_photo")
    room=request.files.get("seating_photo")
    if not rel or not room:
        return jsonify(error="관계표 사진과 자리 모양 사진을 모두 올려 주세요."),400
    try:
        data=ask_ai(image_data(rel),image_data(room))
        return jsonify(optimize(data))
    except ValueError as e:
        return jsonify(error=str(e)),400
    except Exception as e:
        app.logger.exception("analysis failed")
        return jsonify(error="분석 중 오류가 발생했어요. 사진을 다시 확인하거나 서버 설정을 점검해 주세요."),500

if __name__ == "__main__":
    app.run(host="0.0.0.0",port=int(os.getenv("PORT","5000")),debug=False)
